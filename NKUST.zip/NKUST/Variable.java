public class Variable {
    public static void main(String[] args) {
        String myName = "Henry Kao";
        System.out.println("Hello "+myName);
    }
}
