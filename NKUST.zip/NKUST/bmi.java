public class bmi {
    public static void main(String[] args) {
        float high = 1.75f;
        int weight = 72;
        float bmi =   weight/(high*high);
        System.out.println(bmi);
    }
}
