public class test {
    public static void main(String[] args) {
        int a = 1;
        System.out.println(a);
        System.out.println(a++);
        System.out.println(a);

        System.out.println(++a);
    }
}
